// Demo heuristics: calibrate against labelled field images before real deployment.
export const POLICY = Object.freeze({
  low: 20, medium: 50, high: 70, critical: 90,
  minConfidence: 0.5,
  readingMaxAgeMs: 15 * 60_000,
  maxFutureSkewMs: 5 * 60_000,
  maxObservationsPerCamera: 100,
  maxImageBytes: 5 * 1024 * 1024,
  maxJsonBytes: 64 * 1024,
});
