API	Chức năng
POST /api/cameras	Thêm camera và tọa độ
POST /api/road-alerts	Thêm tuyến LineString
PATCH/DELETE /api/cameras/:id	Sửa/xóa camera
PATCH/DELETE /api/road-alerts/:id	Sửa/xóa tuyến
POST /api/esp32/cameras/:id/capture	Nhận ảnh JPEG
GET /api/ai/jobs	Lấy ảnh chờ AI
POST /api/ai/results	Nhận kết quả AI
POST /api/test/simulate	Test cảnh báo không cần ảnh
POST /api/road-alerts/:id/alert

## API AI và dự báo mưa mới

- `POST /api/ai/reports`: nhận `waste_level`, `flood_percentage`, `image_url`, `camera_id`.
- `GET /api/weather/cameras`: dự báo 12 giờ tới tại tọa độ camera đã lưu.

Xem [hướng dẫn header/body và checkbox vùng mưa](../docs/AI-WEATHER.md), hoặc chạy các request trong [ai-weather.http](../docs/ai-weather.http).
