import { POLICY } from './config.js';
export const LEVELS = ['normal','low','medium','high','critical'];
export function evaluateSeverity(waste, blockage, rain = false) {
  const score = Math.max(waste, blockage);
  let rank = score >= POLICY.critical ? 4 : score >= POLICY.high ? 3 : score >= POLICY.medium ? 2 : score >= POLICY.low ? 1 : 0;
  if (rain && rank >= 2) rank = Math.min(4, rank + 1);
  return LEVELS[rank];
}
const fresh = (time, now) => Number.isFinite(Date.parse(time)) && now - Date.parse(time) <= POLICY.readingMaxAgeMs && Date.parse(time) <= now + POLICY.maxFutureSkewMs;
export function publicCamera(camera, now = Date.now()) {
  const { observations, latest_analysis, ...metadata } = camera;
  return {
    ...metadata,
    status: camera.last_seen_at ? (fresh(camera.last_seen_at,now) ? 'online' : 'offline') : camera.status ?? 'unknown',
    ...(latest_analysis ? { monitoring:latest_analysis.monitoring, images:latest_analysis.images, analysis_source:latest_analysis.simulated?'simulation':'ai', analysis_status: fresh(latest_analysis.captured_at,now) ? 'fresh' : 'stale' } : {}),
    pending_count: (observations ?? []).filter(o => o.status === 'pending').length,
  };
}
export function aggregateRoad(road, cameras, now = Date.now()) {
  const {manual_alert,weather,...base} = road;
  const linked = cameras.filter(c => c.road_id === road.road_id);
  const readings = linked.map(c=>c.latest_analysis).filter(a=>a && fresh(a.captured_at,now));
  const rain = weather && fresh(weather.observed_at,now) ? weather.rain_expected : undefined;
  const manual = manual_alert && Date.parse(manual_alert.expires_at) > now ? manual_alert : undefined;
  let monitoring = linked.length ? undefined : base.monitoring;
  let severity = linked.length ? 'normal' : base.severity;
  if (readings.length) {
    const maximum = key => { const values=readings.map(a=>a.monitoring[key]).filter(v=>typeof v==='number');return values.length?Math.max(...values):undefined; };
    const waste = maximum('waste_coverage_pct');
    const blockage = maximum('drain_blockage_pct');
    const flood = maximum('flood_percentage');
    const wasteLevels=readings.map(a=>a.monitoring.waste_level).filter(v=>LEVELS.includes(v));
    const wasteLevel=wasteLevels.sort((a,b)=>LEVELS.indexOf(b)-LEVELS.indexOf(a))[0];
    severity = LEVELS[Math.max(LEVELS.indexOf(evaluateSeverity(Math.max(waste??0,flood??0),blockage??0)),LEVELS.indexOf(wasteLevel??'normal'))];
    if(rain&&LEVELS.indexOf(severity)>=2)severity=LEVELS[Math.min(4,LEVELS.indexOf(severity)+1)];
    monitoring = { waste_coverage_pct:waste, drain_blockage_pct:blockage, waste_level:wasteLevel, flood_percentage:flood,
      // Demo risk proxy, not measured water level or hydrological prediction.
      flood_risk:severity, observed_at:readings.map(a=>a.captured_at).sort()[0] };
  }
  if (rain !== undefined) monitoring = {...monitoring, rain_expected:rain};
  if (rain && LEVELS.indexOf(severity) < 2) severity = 'medium';
  if (manual && LEVELS.indexOf(manual.severity) > LEVELS.indexOf(severity)) severity = manual.severity;
  const incidentIds = readings.filter(a=>a.incident_id).map(a=>a.incident_id).sort();
  if (manual) incidentIds.push(manual.alert_id);
  if (rain) incidentIds.push(weather.event_id);
  const quality = linked.length ? (readings.length === linked.length ? 'fresh' : readings.length ? 'partial' : 'unknown') : 'unconfigured';
  const warnings = linked.length && readings.length < linked.length ? ` ${linked.length-readings.length}/${linked.length} camera chưa có phân tích còn hiệu lực.` : '';
  return {...base, severity, monitoring,
    alert_id:severity !== 'normal' ? (incidentIds.join(':') || base.alert_id) : undefined,
    description:(readings.some(a=>a.simulated)?'[Dữ liệu mô phỏng qua API test] ':'')+(manual?.description ?? base.description ?? 'Tổng hợp mức rủi ro theo camera.') + warnings,
    data_quality:quality, camera_count:linked.length, analyzed_camera_count:readings.length,
    manual_alert:manual, weather:weather && fresh(weather.observed_at,now) ? weather : undefined,
  };
}
