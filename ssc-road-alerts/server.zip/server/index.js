import { createApiServer } from './app.js';
const port = Number(process.env.PORT || 8000);
const host = process.env.HOST || '127.0.0.1';
if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('PORT không hợp lệ');
const server = createApiServer({
  allowedOrigin: process.env.FRONTEND_ORIGIN || 'http://localhost:5173',
  apiKey: process.env.ADMIN_API_KEY || '',
  deviceKey: process.env.DEVICE_API_KEY || process.env.ADMIN_API_KEY || '',
  aiKey: process.env.AI_API_KEY || process.env.ADMIN_API_KEY || '',
  enableTestApi: process.env.ENABLE_TEST_API !== 'false',
});
server.on('error',error=>{console.error(error.message);process.exitCode=1;});
server.listen(port,host,()=>console.log(`SSC API: http://${host}:${port}/api/health`));
for (const signal of ['SIGINT','SIGTERM']) process.on(signal,()=>server.close(()=>process.exit(0)));
